#define INPUT_DIR "/home/gustavo/Documents/Trabalhos/Grafos2022/tests/input/"
#define EXPECTED_OUTPUT_DIR "/home/gustavo/Documents/Trabalhos/Grafos2022/tests/expected_output/"
#define ROOT_DIR "/home/gustavo/Documents/Trabalhos/Grafos2022/"
/* #undef TEST_CASE */
/* #undef OUTPUTMODE_FILESYSTEM */
/* #undef TEST_SUIT */

#define ROOT_DIR "/home/gustavo/Documents/Trabalhos/Grafos2022/"
#ifndef TEST_CASE
  #define OUTPUT_FILES_DIRECTORY "/home/gustavo/Documents/Trabalhos/Grafos2022/output/"
  #define TEST_CASE 
#endif
#define TEST_SUIT 

#define OUTPUTMODE_FILESYSTEM 
